import 'react-native-gesture-handler';
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  StyleSheet,
  Alert,
} from "react-native";

import QRCode from "react-native-qrcode-svg";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

const Tab = createBottomTabNavigator();

/* ---------------- MENU DATA ---------------- */
const MENU = [
  {
    id: 1,
    name: "Zinger Burger",
    price: 6,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349",
  },
  {
    id: 2,
    name: "Cheese Pizza",
    price: 9,
    image: "https://images.unsplash.com/photo-1548365328-9f547f6d0e1b",
  },
  {
    id: 3,
    name: "Cream Pasta",
    price: 7,
    image: "https://images.unsplash.com/photo-1525755662778-989d0524087e",
  },
];

/* ---------------- LOGIN ---------------- */
function Login({ setUser }) {
  const [name, setName] = useState("");

  return (
    <View style={styles.login}>
      <Text style={styles.logo}>💜 DineXpert</Text>
      <Text style={styles.subtitle}>Restaurant Dashboard System</Text>

      <TextInput
        placeholder="Enter Name"
        placeholderTextColor="#ccc"
        style={styles.input}
        onChangeText={setName}
      />

      <TouchableOpacity
        style={styles.primaryBtn}
        onPress={() => {
          if (!name) return Alert.alert("Error", "Enter name first");
          setUser(name);
        }}
      >
        <Text style={styles.btnText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
}

/* ---------------- DASHBOARD ---------------- */
function Dashboard({ user, setUser }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome, {user} 👋</Text>

      <View style={styles.card}>
        <Text style={{ fontSize: 16 }}>🍽️ Browse Menu</Text>
      </View>

      <View style={styles.card}>
        <Text style={{ fontSize: 16 }}>📦 Track Orders</Text>
      </View>

      <View style={styles.card}>
        <Text style={{ fontSize: 16 }}>📅 Make Reservation</Text>
      </View>

      <TouchableOpacity
        style={[styles.primaryBtn, { marginTop: 20 }]}
        onPress={() => setUser(null)}
      >
        <Text style={styles.btnText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
}

/* ---------------- MENU ---------------- */
function Menu({ cart, setCart }) {
  const addToCart = (item) => {
    const exist = cart.find((c) => c.id === item.id);

    if (exist) {
      setCart(
        cart.map((c) =>
          c.id === item.id ? { ...c, qty: c.qty + 1 } : c
        )
      );
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
    }

    Alert.alert("Added", item.name);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu</Text>

      <FlatList
        data={MENU}
        keyExtractor={(i) => i.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <Text style={styles.food}>{item.name}</Text>
            <Text style={styles.price}>${item.price}</Text>

            <TouchableOpacity
              style={styles.secondaryBtn}
              onPress={() => addToCart(item)}
            >
              <Text style={styles.btnText}>Add to Cart</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

/* ---------------- CART + ORDER ---------------- */
function Cart({ cart, setCart, orders, setOrders }) {
  const total = cart.reduce((sum, i) => sum + i.price * i.qty, 0);

  const placeOrder = () => {
    if (cart.length === 0)
      return Alert.alert("Empty Cart", "Add items first");

    const newOrder = {
      id: Date.now(),
      total,
      status: "Confirmed ✔",
    };

    setOrders([newOrder, ...orders]);
    setCart([]);

    Alert.alert("🎉 Order Placed!", `Order ID: ${newOrder.id}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cart</Text>

      {cart.map((i) => (
        <Text key={i.id}>
          {i.name} x {i.qty}
        </Text>
      ))}

      <Text style={styles.total}>Total: ${total}</Text>

      <TouchableOpacity style={styles.primaryBtn} onPress={placeOrder}>
        <Text style={styles.btnText}>Place Order</Text>
      </TouchableOpacity>
    </View>
  );
}

/* ---------------- ORDERS ---------------- */
function Orders({ orders }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Orders</Text>

      {orders.length === 0 ? (
        <Text>No orders yet</Text>
      ) : (
        orders.map((o) => (
          <View key={o.id} style={styles.card}>
            <Text>Order ID: {o.id}</Text>
            <Text style={{ color: "#6a0dad" }}>{o.status}</Text>
            <Text>Total: ${o.total}</Text>
          </View>
        ))
      )}
    </View>
  );
}

/* ---------------- RESERVATION ---------------- */
function Reservation({ user }) {
  return (
    <View style={styles.center}>
      <Text style={styles.title}>Reservation</Text>

      <Text>Reserved for {user}</Text>

      <QRCode value={`DineXpert-${user}`} size={200} />
    </View>
  );
}

/* ---------------- MAIN APP ---------------- */
function MainApp({ user, setUser }) {
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);

  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: "#6a0dad" },
        headerTintColor: "#fff",
        tabBarStyle: { backgroundColor: "#6a0dad" },
        tabBarActiveTintColor: "#fff",
      }}
    >
      <Tab.Screen name="Dashboard">
        {() => <Dashboard user={user} setUser={setUser} />}
      </Tab.Screen>

      <Tab.Screen name="Menu">
        {() => <Menu cart={cart} setCart={setCart} />}
      </Tab.Screen>

      <Tab.Screen name="Cart">
        {() => (
          <Cart
            cart={cart}
            setCart={setCart}
            orders={orders}
            setOrders={setOrders}
          />
        )}
      </Tab.Screen>

      <Tab.Screen name="Orders">
        {() => <Orders orders={orders} />}
      </Tab.Screen>

      <Tab.Screen name="Reserve">
        {() => <Reservation user={user} />}
      </Tab.Screen>
    </Tab.Navigator>
  );
}

/* ---------------- ROOT ---------------- */
export default function App() {
  const [user, setUser] = useState(null);

  if (!user) return <Login setUser={setUser} />;

  return (
    <NavigationContainer>
      <MainApp user={user} setUser={setUser} />
    </NavigationContainer>
  );
}

/* ---------------- STYLES ---------------- */
const styles = StyleSheet.create({
  container: { flex: 1, padding: 15, backgroundColor: "#f8f5ff" },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  login: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#4B0082",
  },

  logo: { fontSize: 30, color: "#fff", fontWeight: "bold" },
  subtitle: { color: "#ddd", marginBottom: 20 },

  input: {
    width: "80%",
    borderWidth: 1,
    borderColor: "#fff",
    color: "#fff",
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },

  title: { fontSize: 22, fontWeight: "bold", marginBottom: 10 },

  primaryBtn: {
    backgroundColor: "#9b59b6",
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },

  secondaryBtn: {
    backgroundColor: "#6a0dad",
    padding: 8,
    borderRadius: 8,
    marginTop: 10,
  },

  btnText: { color: "white", textAlign: "center", fontWeight: "bold" },

  card: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
  },

  image: { width: "100%", height: 150, borderRadius: 10 },

  food: { fontSize: 18, fontWeight: "bold", marginTop: 5 },

  price: { color: "#6a0dad", fontWeight: "bold" },

  total: { fontSize: 18, fontWeight: "bold", marginTop: 10 },
});